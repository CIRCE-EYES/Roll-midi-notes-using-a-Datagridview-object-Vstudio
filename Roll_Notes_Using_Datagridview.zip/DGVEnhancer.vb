﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Linq
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Namespace Slow_DGV_Population

	Public Module DGVEnhancer

		<DllImport("user32.dll")>
		Public Function SendMessage(hWnd As IntPtr, wMsg As Int32, wParam As Boolean, lParam As Int32) As Integer
		End Function

		<System.Runtime.CompilerServices.Extension>
		Public Sub SetDoubleBuffering(dgv As DataGridView, value As Boolean)

			' Double buffering can make DGV slow in remote desktop
			If Not System.Windows.Forms.SystemInformation.TerminalServerSession Then

				Dim dgvType As Type = dgv.GetType()
				Dim pi As PropertyInfo = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance Or BindingFlags.NonPublic)
				pi.SetValue(dgv, value, Nothing)

			End If

		End Sub

	End Module

End Namespace
