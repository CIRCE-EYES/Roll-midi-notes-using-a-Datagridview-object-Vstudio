Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Imports System.IO

Imports Melanchall.DryWetMidi.Devices
Imports Melanchall.DryWetMidi.Common
Imports Melanchall.DryWetMidi.Interaction
Imports Melanchall.DryWetMidi.Core
Imports System.ComponentModel
Imports Piano.Slow_DGV_Population ' for double buffer antiflicker datagrid....USEFULL !!!!!
Imports System.Linq

Partial Public Class frmPiano
    Inherits Form
    Public _outputDevice As OutputDevice
    Public _playback As Playback

    Dim a As Short
    Dim valuebpm As Integer

    Public Sub frmPiano_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each portname_out In OutputDevice.GetAll
            Combo_output.Items.Add(portname_out)
        Next

        Combo_output.SelectedIndex = 0

        _outputDevice = CType(Combo_output.SelectedItem, OutputDevice)

    End Sub
    Public Sub Combo_output_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combo_output.SelectedIndexChanged
        _outputDevice = CType(Combo_output.SelectedItem, OutputDevice)
    End Sub
    Private Sub pKey_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles pKey.MouseDown
        Dim Index As Short = pKey.GetIndex(eventSender)
        domusic(Index)
    End Sub
    Private Sub pKey_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles pKey.MouseUp
        Dim Index As Short = pKey.GetIndex(eventSender)
        domusicstop(Index)
    End Sub

    Public Sub domusic(ByRef mNote As Integer)
        Dim Volume As Integer

        Volume = 120
            _outputDevice.SendEvent(New NoteOnEvent(mNote, CType(Volume, SevenBitNumber)))
            pKey(mNote).BackColor = System.Drawing.Color.Red

    End Sub

    Public Sub domusicstop(ByRef mNote As SevenBitNumber)
        _outputDevice.SendEvent(New NoteOffEvent(mNote, CType(0, SevenBitNumber)))

        If pKey(mNote).Tag = "1" Then
            pKey(mNote).BackColor = System.Drawing.Color.White
        Else
            pKey(mNote).BackColor = System.Drawing.Color.Black
        End If

    End Sub

    Public Sub STOPLISTBOX()
        Dim X As Integer
        For X = 0 To 71 '(stop all notes)
            domusicstop(X)
        Next X
    End Sub

    Public Sub frmPiano_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        ' _playback.Dispose()
        ' _outputDevice.Dispose()
    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked = True Then
            GRID.Visible = True
            GRID.Location = New Point(50, 400)

        Else
            GRID.Visible = False
        End If
    End Sub


End Class