﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GRID
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.SAVE_GRID = New System.Windows.Forms.Button()
        Me.LOAD_GRID = New System.Windows.Forms.Button()
        Me.Stop_Roll = New System.Windows.Forms.Button()
        Me.Play_Roll = New System.Windows.Forms.Button()
        Me.chkDoubleBuffering = New System.Windows.Forms.CheckBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column0 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Text_BPM = New System.Windows.Forms.TextBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Transpose_Up = New System.Windows.Forms.Button()
        Me.Transpose_Down = New System.Windows.Forms.Button()
        Me.New_Grid = New System.Windows.Forms.Button()
        Me.del_last_cell = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Button8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button8.Location = New System.Drawing.Point(12, 11)
        Me.Button8.Name = "Button8"
        Me.Button8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button8.Size = New System.Drawing.Size(172, 35)
        Me.Button8.TabIndex = 523
        Me.Button8.Text = "Play Grid begin"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Turquoise
        Me.Button7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Button7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button7.Location = New System.Drawing.Point(902, 48)
        Me.Button7.Name = "Button7"
        Me.Button7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button7.Size = New System.Drawing.Size(90, 42)
        Me.Button7.TabIndex = 522
        Me.Button7.Text = "Clear column selected"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'SAVE_GRID
        '
        Me.SAVE_GRID.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.SAVE_GRID.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.SAVE_GRID.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAVE_GRID.ForeColor = System.Drawing.Color.White
        Me.SAVE_GRID.Location = New System.Drawing.Point(477, 11)
        Me.SAVE_GRID.Name = "SAVE_GRID"
        Me.SAVE_GRID.Size = New System.Drawing.Size(96, 43)
        Me.SAVE_GRID.TabIndex = 517
        Me.SAVE_GRID.Text = "Save Grid"
        Me.SAVE_GRID.UseVisualStyleBackColor = False
        '
        'LOAD_GRID
        '
        Me.LOAD_GRID.BackColor = System.Drawing.Color.ForestGreen
        Me.LOAD_GRID.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LOAD_GRID.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LOAD_GRID.ForeColor = System.Drawing.Color.White
        Me.LOAD_GRID.Location = New System.Drawing.Point(375, 11)
        Me.LOAD_GRID.Name = "LOAD_GRID"
        Me.LOAD_GRID.Size = New System.Drawing.Size(96, 43)
        Me.LOAD_GRID.TabIndex = 516
        Me.LOAD_GRID.Text = "Load Grid"
        Me.LOAD_GRID.UseVisualStyleBackColor = False
        '
        'Stop_Roll
        '
        Me.Stop_Roll.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Stop_Roll.Cursor = System.Windows.Forms.Cursors.Default
        Me.Stop_Roll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Stop_Roll.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Stop_Roll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Stop_Roll.Location = New System.Drawing.Point(192, 11)
        Me.Stop_Roll.Name = "Stop_Roll"
        Me.Stop_Roll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Stop_Roll.Size = New System.Drawing.Size(172, 74)
        Me.Stop_Roll.TabIndex = 515
        Me.Stop_Roll.Text = "Stop Grid"
        Me.Stop_Roll.UseVisualStyleBackColor = False
        '
        'Play_Roll
        '
        Me.Play_Roll.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Play_Roll.Cursor = System.Windows.Forms.Cursors.Default
        Me.Play_Roll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Play_Roll.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Play_Roll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Play_Roll.Location = New System.Drawing.Point(12, 51)
        Me.Play_Roll.Name = "Play_Roll"
        Me.Play_Roll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Play_Roll.Size = New System.Drawing.Size(172, 34)
        Me.Play_Roll.TabIndex = 514
        Me.Play_Roll.Text = "Play Grid from.."
        Me.Play_Roll.UseVisualStyleBackColor = False
        '
        'chkDoubleBuffering
        '
        Me.chkDoubleBuffering.AutoSize = True
        Me.chkDoubleBuffering.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.chkDoubleBuffering.Location = New System.Drawing.Point(799, 65)
        Me.chkDoubleBuffering.Name = "chkDoubleBuffering"
        Me.chkDoubleBuffering.Size = New System.Drawing.Size(101, 19)
        Me.chkDoubleBuffering.TabIndex = 513
        Me.chkDoubleBuffering.Text = "Double Buffer"
        Me.chkDoubleBuffering.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(477, 60)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(96, 25)
        Me.Button3.TabIndex = 512
        Me.Button3.Text = "Tiny Grid"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(374, 60)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(97, 25)
        Me.Button2.TabIndex = 511
        Me.Button2.Text = "Big Grid"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Turquoise
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Button1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(902, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button1.Size = New System.Drawing.Size(90, 43)
        Me.Button1.TabIndex = 510
        Me.Button1.Text = "Clear All notes"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.DimGray
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.ColumnHeadersHeight = 28
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column0})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.DimGray
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Crimson
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView1.GridColor = System.Drawing.Color.Black
        Me.DataGridView1.Location = New System.Drawing.Point(11, 95)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidth = 30
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView1.ShowCellErrors = False
        Me.DataGridView1.ShowCellToolTips = False
        Me.DataGridView1.ShowEditingIcon = False
        Me.DataGridView1.ShowRowErrors = False
        Me.DataGridView1.Size = New System.Drawing.Size(1092, 510)
        Me.DataGridView1.StandardTab = True
        Me.DataGridView1.TabIndex = 524
        '
        'Column0
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White
        Me.Column0.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Column0.HeaderText = "Invisible"
        Me.Column0.MinimumWidth = 10
        Me.Column0.Name = "Column0"
        Me.Column0.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column0.Visible = False
        Me.Column0.Width = 77
        '
        'TextBox1
        '
        Me.TextBox1.AcceptsReturn = True
        Me.TextBox1.BackColor = System.Drawing.Color.Black
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TextBox1.Location = New System.Drawing.Point(642, 62)
        Me.TextBox1.MaxLength = 0
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox1.Size = New System.Drawing.Size(31, 24)
        Me.TextBox1.TabIndex = 525
        Me.TextBox1.Text = "1"
        '
        'Text_BPM
        '
        Me.Text_BPM.AcceptsReturn = True
        Me.Text_BPM.BackColor = System.Drawing.Color.Black
        Me.Text_BPM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Text_BPM.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text_BPM.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text_BPM.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Text_BPM.Location = New System.Drawing.Point(754, 60)
        Me.Text_BPM.MaxLength = 0
        Me.Text_BPM.Name = "Text_BPM"
        Me.Text_BPM.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text_BPM.Size = New System.Drawing.Size(33, 26)
        Me.Text_BPM.TabIndex = 526
        Me.Text_BPM.Text = "120"
        '
        'Timer2
        '
        Me.Timer2.Interval = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(696, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 24)
        Me.Label1.TabIndex = 527
        Me.Label1.Text = "BPM"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(582, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 15)
        Me.Label2.TabIndex = 528
        Me.Label2.Text = "Column"
        '
        'Transpose_Up
        '
        Me.Transpose_Up.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.Transpose_Up.Cursor = System.Windows.Forms.Cursors.Default
        Me.Transpose_Up.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Transpose_Up.ForeColor = System.Drawing.Color.White
        Me.Transpose_Up.Location = New System.Drawing.Point(1013, 48)
        Me.Transpose_Up.Name = "Transpose_Up"
        Me.Transpose_Up.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Transpose_Up.Size = New System.Drawing.Size(90, 42)
        Me.Transpose_Up.TabIndex = 529
        Me.Transpose_Up.Text = "Transpose UP"
        Me.Transpose_Up.UseVisualStyleBackColor = False
        '
        'Transpose_Down
        '
        Me.Transpose_Down.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.Transpose_Down.Cursor = System.Windows.Forms.Cursors.Default
        Me.Transpose_Down.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Transpose_Down.ForeColor = System.Drawing.Color.White
        Me.Transpose_Down.Location = New System.Drawing.Point(1013, 6)
        Me.Transpose_Down.Name = "Transpose_Down"
        Me.Transpose_Down.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Transpose_Down.Size = New System.Drawing.Size(90, 42)
        Me.Transpose_Down.TabIndex = 530
        Me.Transpose_Down.Text = "Transpose Down"
        Me.Transpose_Down.UseVisualStyleBackColor = False
        '
        'New_Grid
        '
        Me.New_Grid.BackColor = System.Drawing.Color.Turquoise
        Me.New_Grid.Cursor = System.Windows.Forms.Cursors.Default
        Me.New_Grid.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.New_Grid.ForeColor = System.Drawing.SystemColors.ControlText
        Me.New_Grid.Location = New System.Drawing.Point(807, 11)
        Me.New_Grid.Name = "New_Grid"
        Me.New_Grid.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.New_Grid.Size = New System.Drawing.Size(78, 42)
        Me.New_Grid.TabIndex = 533
        Me.New_Grid.Text = "Del Grid"
        Me.New_Grid.UseVisualStyleBackColor = False
        '
        'del_last_cell
        '
        Me.del_last_cell.BackColor = System.Drawing.Color.Turquoise
        Me.del_last_cell.Cursor = System.Windows.Forms.Cursors.Default
        Me.del_last_cell.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.del_last_cell.ForeColor = System.Drawing.SystemColors.ControlText
        Me.del_last_cell.Location = New System.Drawing.Point(693, 13)
        Me.del_last_cell.Name = "del_last_cell"
        Me.del_last_cell.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.del_last_cell.Size = New System.Drawing.Size(96, 41)
        Me.del_last_cell.TabIndex = 532
        Me.del_last_cell.Text = "Del 4"
        Me.del_last_cell.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Turquoise
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Button5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button5.Location = New System.Drawing.Point(579, 12)
        Me.Button5.Name = "Button5"
        Me.Button5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button5.Size = New System.Drawing.Size(96, 42)
        Me.Button5.TabIndex = 531
        Me.Button5.Text = "Add 4"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'GRID
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1119, 616)
        Me.Controls.Add(Me.Text_BPM)
        Me.Controls.Add(Me.New_Grid)
        Me.Controls.Add(Me.del_last_cell)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Transpose_Down)
        Me.Controls.Add(Me.Transpose_Up)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.SAVE_GRID)
        Me.Controls.Add(Me.LOAD_GRID)
        Me.Controls.Add(Me.Stop_Roll)
        Me.Controls.Add(Me.Play_Roll)
        Me.Controls.Add(Me.chkDoubleBuffering)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "GRID"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "GRID"
        Me.TopMost = True
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents Button8 As Button
    Public WithEvents Button7 As Button
    Friend WithEvents SAVE_GRID As Button
    Friend WithEvents LOAD_GRID As Button
    Public WithEvents Stop_Roll As Button
    Public WithEvents Play_Roll As Button
    Private WithEvents chkDoubleBuffering As CheckBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Public WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Public WithEvents TextBox1 As TextBox
    Public WithEvents Text_BPM As TextBox
    Public WithEvents Timer2 As Timer
    Friend WithEvents Column0 As DataGridViewButtonColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Public WithEvents Transpose_Up As Button
    Public WithEvents Transpose_Down As Button
    Public WithEvents New_Grid As Button
    Public WithEvents del_last_cell As Button
    Public WithEvents Button5 As Button
End Class
