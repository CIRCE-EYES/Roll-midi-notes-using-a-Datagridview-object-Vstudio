﻿Imports VB = Microsoft.VisualBasic
Imports System.IO
Imports System.ComponentModel
Imports System.Linq
Imports Piano.Slow_DGV_Population
Public Class GRID
    Inherits Form
    Public Sub New()
        InitializeComponent()
    End Sub
    Dim a As Short

    Public Sub chkDoubleBuffering_CheckedChanged(sender As Object, e As EventArgs) Handles chkDoubleBuffering.CheckedChanged
        If Not Me.chkDoubleBuffering.IsHandleCreated Then Return
        DataGridView1.SetDoubleBuffering(chkDoubleBuffering.Checked)
    End Sub

    Private Const CP_NOCLOSE_BUTTON As Integer = &H200
    Protected Overloads Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim myCp As CreateParams = MyBase.CreateParams
            myCp.ClassStyle = myCp.ClassStyle Or CP_NOCLOSE_BUTTON
            Return myCp
        End Get
    End Property


    Public Sub GRID_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Rows.Add(71)

        For i As Integer = 0 To DataGridView1.Rows.Count - 1    '' it appears 0 to 71
            '  For i As Integer = 71 To 0 Step -1 ' it appears the same order ....brrrrrrr !!!

            For j As Integer = 0 To DataGridView1.Columns.Count - 1

                DataGridView1.Rows(i).Cells(j).Value = i  ' here the index must appear =  71 to 0 instead 0 to 71 in the cells

            Next j

        Next i

        For i = 0 To DataGridView1.Rows.Count - 1
            DataGridView1.Rows(i).Height = 16
        Next

        DataGridView1.FirstDisplayedScrollingRowIndex = 24

        chkDoubleBuffering.Checked = True
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If DataGridView1.CurrentCell Is Nothing Then
            MessageBox.Show("Grid Empty")
            Exit Sub
        End If

        colSelected = TextBox1.Text
        For todo = 0 To DataGridView1.Rows.Count - 1
            DataGridView1.Rows(todo).Cells(colSelected).Style.BackColor = Color.DimGray
            DataGridView1.Rows(todo).Cells(colSelected).Selected = False
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i As Integer = 0 To DataGridView1.Rows.Count - 1

            For j As Integer = 0 To DataGridView1.Columns.Count - 1
                DataGridView1.Rows(i).Cells(j).Style.BackColor = Color.DimGray

            Next j
        Next i
        DataGridView1.ClearSelection()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        For i As Integer = 0 To DataGridView1.Rows.Count - 1

            For j As Integer = 0 To DataGridView1.Columns.Count - 1
                DataGridView1.Rows(i).Height = DataGridView1.Rows(i).Height + 2

            Next j

        Next i
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        For i As Integer = 0 To DataGridView1.Rows.Count - 1

            For j As Integer = 0 To DataGridView1.Columns.Count - 1
                DataGridView1.Rows(i).Height = DataGridView1.Rows(i).Height - 2

            Next j

        Next i
    End Sub

    Private Sub DataGridView1_CellMouseDown(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseDown

        Dim col As Integer = e.ColumnIndex
        Dim row As Integer = e.RowIndex

        If e.RowIndex = -1 Then

            For index = 0 To DataGridView1.Rows.Count - 1

                If DataGridView1.Item(col, index).Style.BackColor = Color.Crimson Then
                    DataGridView1.CurrentCell = DataGridView1.Rows(index).Cells(col)
                    frmPiano.domusic(DataGridView1.Item(col, index).Value)
                    DataGridView1.Columns(e.ColumnIndex).HeaderCell.Style.BackColor = Color.YellowGreen
                End If
            Next

        Else
            frmPiano.domusic(DataGridView1.Item(col, row).Value)
            DataGridView1.Item(col, row).Style.BackColor = Color.Crimson

        End If

    End Sub

    Private Sub DataGridView1_CellMouseUp(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseUp

        Dim col As Integer = e.ColumnIndex
        Dim row As Integer = e.RowIndex
        DataGridView1.Item(1, 24).Selected = False ' a bug that appear selected number 24

        TextBox1.Text = e.ColumnIndex.ToString

        If e.RowIndex = -1 Then
            DataGridView1.Columns(e.ColumnIndex).HeaderCell.Style.BackColor = Color.DimGray
            frmPiano.STOPLISTBOX()
            Return
        End If
        playChordE(DataGridView1.Item(col, row).Value)

        If e.Button = MouseButtons.Right Then

            DataGridView1.Columns(e.ColumnIndex).HeaderCell.Style.BackColor = Color.DimGray
            DataGridView1.Item(col, row).Style.BackColor = Color.DimGray
            DataGridView1.Item(col, row).Selected = False

        End If

    End Sub

    Private Sub Play_Roll_Click(sender As Object, e As EventArgs) Handles Play_Roll.Click
        If DataGridView1.CurrentCell Is Nothing Then
            MessageBox.Show("Grid Empty")
            Exit Sub
        End If

        Dim tempo As Single

        Stop_Roll.PerformClick()
        tempo = Val(Text_BPM.Text)

        Timer2.Interval = 60 * (1000 / tempo)
        Timer2.Enabled = True
    End Sub

    Dim columnIndex As Integer
    Dim colSelected As Integer = 1
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick

        Dim total = DataGridView1.Columns.Count
        If Not TextBox1.Text = "" Then
            colSelected = TextBox1.Text
        End If

        If columnIndex >= colSelected And columnIndex < total Then
            DataGridView1.Columns(columnIndex - 1).HeaderCell.Style.BackColor = Color.DimGray
        ElseIf total = columnIndex Then
            DataGridView1.Columns(columnIndex - 1).HeaderCell.Style.BackColor = Color.DimGray
        End If

        frmPiano.STOPLISTBOX()
        If columnIndex < total Then
            Dim header As New DataGridViewCellMouseEventArgs(columnIndex, -1, 0, 0, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
            DataGridView1_CellMouseDown(New Object(), header)
        Else
            columnIndex = colSelected
            Dim header As New DataGridViewCellMouseEventArgs(columnIndex, -1, 0, 0, New MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0))
            DataGridView1_CellMouseDown(New Object(), header)
        End If
        columnIndex += 1
    End Sub

    Private Sub Stop_Roll_Click(sender As Object, e As EventArgs) Handles Stop_Roll.Click
        frmPiano.STOPLISTBOX()
        Timer2.Enabled = False
        ' DataGridView1.Columns(columnIndex - 1).HeaderCell.Style.BackColor = Color.darkwhite
        columnIndex = TextBox1.Text
        colSelected = TextBox1.Text
    End Sub

    Private Sub LOAD_GRID_Click(sender As Object, e As EventArgs) Handles LOAD_GRID.Click

        Dim FileOpen As New OpenFileDialog()
        FileOpen.Filter = "GRID Files (*.grid*)|*.grid"
        If FileOpen.ShowDialog() = DialogResult.Cancel Then
            Exit Sub
        Else

            Dim count As Integer = DataGridView1.Columns.Count
            While count > 1
                DataGridView1.Columns.RemoveAt(count - 1)
                count -= 1
            End While

            Dim lines = IO.File.ReadAllLines(FileOpen.FileName)
            Dim cols = lines(0).Split(","c)
            For i As Int32 = 1 To cols.Count - 1
                Dim Flatty2 As New DataGridViewButtonColumn
                DataGridView1.Columns.Add(Flatty2)
                Flatty2.FlatStyle = FlatStyle.Flat
                Flatty2.HeaderText = cols(i)
                Flatty2.Width = 77
            Next
            Dim index = 0
            For Each line In lines
                If lines(0) = line Then
                    Continue For
                End If
                Dim objFields = line.Split(","c)
                For j As Integer = 0 To objFields.Count - 1
                    If objFields(j).Contains("Crimson") Then
                        DataGridView1.Rows(index).Cells(j).Style.BackColor = Color.Crimson
                        DataGridView1.Rows(index).Cells(j).Value = objFields(j).Replace("Crimson", String.Empty)
                    Else
                        DataGridView1.Rows(index).Cells(j).Value = objFields(j)
                    End If
                Next j
                index += 1
            Next
        End If

        For i As Integer = 71 To 0 Step -1       ' this For its neccesary to index cells appears numbers
            For j As Integer = 0 To DataGridView1.Columns.Count - 1
                DataGridView1.Rows(i).Cells(j).Value = i
            Next j
        Next i

    End Sub

    Private Sub SAVE_GRID_Click(sender As Object, e As EventArgs) Handles SAVE_GRID.Click

        If DataGridView1.Columns.Count > 1 Then
            Dim csvFile As String = String.Empty
            For Each col As DataGridViewColumn In DataGridView1.Columns
                csvFile = csvFile & col.HeaderText & ","
            Next
            csvFile = csvFile.TrimEnd(",")
            csvFile = csvFile & vbCr
            'Used to get the rows
            For Each row As DataGridViewRow In DataGridView1.Rows
                'Used to get each cell in the row
                For Each cell As DataGridViewCell In row.Cells
                    If cell.Style.BackColor = Color.Crimson Then
                        csvFile = csvFile & cell.FormattedValue & "Crimson" & ","
                    Else
                        csvFile = csvFile & cell.FormattedValue & ","
                    End If

                Next
                csvFile = csvFile.TrimEnd(",")
                csvFile = csvFile & vbCr
            Next
            Dim SaveFileDialog1 As New SaveFileDialog()
            SaveFileDialog1.Filter = "GRID Files (*.grid*)|*.grid"    ' its just to different format 

            If SaveFileDialog1.ShowDialog = DialogResult.Cancel Then
                MessageBox.Show("Nothing Saved")
                Exit Sub
            Else
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, csvFile, False)
            End If

        Else
            MessageBox.Show("Nothing to save")
        End If

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If DataGridView1.CurrentCell Is Nothing Then
            MessageBox.Show("Grid Empty")
            Exit Sub
        End If

        TextBox1.Text = "1"
        Dim tempo As Single
        Stop_Roll.PerformClick()
        tempo = Val(Text_BPM.Text)

        Timer2.Interval = 60 * (1000 / tempo)
        Timer2.Enabled = True
    End Sub

    Private Sub Transpose_Up_Click(sender As Object, e As EventArgs) Handles Transpose_Up.Click
        Dim i = 0
        For Each col As DataGridViewColumn In DataGridView1.Columns
            For j = 0 To DataGridView1.Rows.Count - 1
                If DataGridView1.Rows(j).Cells(i).Style.BackColor = Color.Crimson Then
                    If Not j = DataGridView1.Rows.Count - 1 Then
                        DataGridView1.Rows(j).Cells(i).Style.BackColor = Color.DimGray
                        j += 1
                        DataGridView1.Rows(j).Cells(i).Style.BackColor = Color.Crimson
                    End If
                End If
            Next
            i += 1
        Next

    End Sub

    Private Sub Transpose_Down_Click(sender As Object, e As EventArgs) Handles Transpose_Down.Click

        Dim i = 0
        For Each col As DataGridViewColumn In DataGridView1.Columns
            For j = 0 To DataGridView1.Rows.Count - 1
                If DataGridView1.Rows(j).Cells(i).Style.BackColor = Color.Crimson Then

                    If Not j = 0 Then
                        DataGridView1.Rows(j).Cells(i).Style.BackColor = Color.DimGray
                        DataGridView1.Rows(j - 1).Cells(i).Style.BackColor = Color.Crimson
                    End If
                End If
            Next
            i += 1
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim Flatty As New DataGridViewButtonColumn
        DataGridView1.Columns.Add(Flatty)
        Flatty.FlatStyle = FlatStyle.Flat
        Flatty.HeaderText = "---"
        Flatty.Width = 77

        Dim Flatty2 As New DataGridViewButtonColumn
        DataGridView1.Columns.Add(Flatty2)
        Flatty2.FlatStyle = FlatStyle.Flat
        Flatty2.HeaderText = "---"
        Flatty2.Width = 77

        Dim Flatty3 As New DataGridViewButtonColumn
        DataGridView1.Columns.Add(Flatty3)
        Flatty3.FlatStyle = FlatStyle.Flat
        Flatty3.HeaderText = "---"
        Flatty3.Width = 77

        Dim Flatty4 As New DataGridViewButtonColumn
        DataGridView1.Columns.Add(Flatty4)
        Flatty4.FlatStyle = FlatStyle.Flat
        Flatty4.HeaderText = "---"
        Flatty4.Width = 77

        For i As Integer = 71 To 0 Step -1          ' this For its neccesary to index cells appears numbers
            For j As Integer = 0 To DataGridView1.Columns.Count - 1
                DataGridView1.Rows(i).Cells(j).Value = i
            Next j
        Next i
    End Sub

    Private Sub del_last_cell_Click(sender As Object, e As EventArgs) Handles del_last_cell.Click
        If DataGridView1.Columns.Count > 4 Then
            For i As Integer = 4 To 1 Step -1
                DataGridView1.Columns.RemoveAt(DataGridView1.Columns.Count - 1)
            Next i
        End If
    End Sub

    Private Sub New_Grid_Click(sender As Object, e As EventArgs) Handles New_Grid.Click
        Dim count As Integer = DataGridView1.Columns.Count
        While count > 1
            DataGridView1.Columns.RemoveAt(count - 1)
            count -= 1
        End While
    End Sub

End Class