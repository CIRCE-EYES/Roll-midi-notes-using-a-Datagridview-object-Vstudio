<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmPiano
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			Static fTerminateCalled As Boolean
			If Not fTerminateCalled Then
                'Form_Terminate_renamed()
                fTerminateCalled = True
			End If
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents _pKey_70 As System.Windows.Forms.Button
    Public WithEvents _pKey_68 As System.Windows.Forms.Button
    Public WithEvents _pKey_66 As System.Windows.Forms.Button
    Public WithEvents _pKey_71 As System.Windows.Forms.Button
    Public WithEvents _pKey_69 As System.Windows.Forms.Button
    Public WithEvents _pKey_67 As System.Windows.Forms.Button
    Public WithEvents _pKey_65 As System.Windows.Forms.Button
    Public WithEvents _pKey_61 As System.Windows.Forms.Button
    Public WithEvents _pKey_63 As System.Windows.Forms.Button
    Public WithEvents _pKey_49 As System.Windows.Forms.Button
    Public WithEvents _pKey_51 As System.Windows.Forms.Button
    Public WithEvents _pKey_54 As System.Windows.Forms.Button
    Public WithEvents _pKey_56 As System.Windows.Forms.Button
    Public WithEvents _pKey_58 As System.Windows.Forms.Button
    Public WithEvents _pKey_46 As System.Windows.Forms.Button
    Public WithEvents _pKey_44 As System.Windows.Forms.Button
    Public WithEvents _pKey_42 As System.Windows.Forms.Button
    Public WithEvents _pKey_39 As System.Windows.Forms.Button
    Public WithEvents _pKey_37 As System.Windows.Forms.Button
    Public WithEvents _pKey_34 As System.Windows.Forms.Button
    Public WithEvents _pKey_32 As System.Windows.Forms.Button
    Public WithEvents _pKey_30 As System.Windows.Forms.Button
    Public WithEvents _pKey_27 As System.Windows.Forms.Button
    Public WithEvents _pKey_25 As System.Windows.Forms.Button
    Public WithEvents _pKey_22 As System.Windows.Forms.Button
    Public WithEvents _pKey_20 As System.Windows.Forms.Button
    Public WithEvents _pKey_18 As System.Windows.Forms.Button
    Public WithEvents _pKey_15 As System.Windows.Forms.Button
    Public WithEvents _pKey_13 As System.Windows.Forms.Button
    Public WithEvents _pKey_10 As System.Windows.Forms.Button
    Public WithEvents _pKey_8 As System.Windows.Forms.Button
    Public WithEvents _pKey_6 As System.Windows.Forms.Button
    Public WithEvents _pKey_3 As System.Windows.Forms.Button
    Public WithEvents _pKey_1 As System.Windows.Forms.Button
    Public WithEvents _pKey_64 As System.Windows.Forms.Button
    Public WithEvents _pKey_62 As System.Windows.Forms.Button
    Public WithEvents _pKey_60 As System.Windows.Forms.Button
    Public WithEvents _pKey_59 As System.Windows.Forms.Button
    Public WithEvents _pKey_57 As System.Windows.Forms.Button
    Public WithEvents _pKey_55 As System.Windows.Forms.Button
    Public WithEvents _pKey_53 As System.Windows.Forms.Button
    Public WithEvents _pKey_52 As System.Windows.Forms.Button
    Public WithEvents _pKey_50 As System.Windows.Forms.Button
    Public WithEvents _pKey_48 As System.Windows.Forms.Button
    Public WithEvents _pKey_47 As System.Windows.Forms.Button
    Public WithEvents _pKey_45 As System.Windows.Forms.Button
    Public WithEvents _pKey_43 As System.Windows.Forms.Button
    Public WithEvents _pKey_41 As System.Windows.Forms.Button
    Public WithEvents _pKey_40 As System.Windows.Forms.Button
    Public WithEvents _pKey_38 As System.Windows.Forms.Button
    Public WithEvents _pKey_36 As System.Windows.Forms.Button
    Public WithEvents _pKey_35 As System.Windows.Forms.Button
    Public WithEvents _pKey_33 As System.Windows.Forms.Button
    Public WithEvents _pKey_31 As System.Windows.Forms.Button
    Public WithEvents _pKey_29 As System.Windows.Forms.Button
    Public WithEvents _pKey_28 As System.Windows.Forms.Button
    Public WithEvents _pKey_26 As System.Windows.Forms.Button
    Public WithEvents _pKey_24 As System.Windows.Forms.Button
    Public WithEvents _pKey_23 As System.Windows.Forms.Button
    Public WithEvents _pKey_21 As System.Windows.Forms.Button
    Public WithEvents _pKey_19 As System.Windows.Forms.Button
    Public WithEvents _pKey_17 As System.Windows.Forms.Button
    Public WithEvents _pKey_16 As System.Windows.Forms.Button
    Public WithEvents _pKey_14 As System.Windows.Forms.Button
    Public WithEvents _pKey_12 As System.Windows.Forms.Button
    Public WithEvents _pKey_11 As System.Windows.Forms.Button
    Public WithEvents _pKey_9 As System.Windows.Forms.Button
    Public WithEvents _pKey_7 As System.Windows.Forms.Button
    Public WithEvents _pKey_5 As System.Windows.Forms.Button
    Public WithEvents _pKey_4 As System.Windows.Forms.Button
    Public WithEvents _pKey_2 As System.Windows.Forms.Button
    Public WithEvents _pKey_0 As System.Windows.Forms.Button
    Public WithEvents pKey As Microsoft.VisualBasic.Compatibility.VB6.ButtonArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPiano))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._pKey_70 = New System.Windows.Forms.Button()
        Me._pKey_68 = New System.Windows.Forms.Button()
        Me._pKey_66 = New System.Windows.Forms.Button()
        Me._pKey_71 = New System.Windows.Forms.Button()
        Me._pKey_69 = New System.Windows.Forms.Button()
        Me._pKey_67 = New System.Windows.Forms.Button()
        Me._pKey_65 = New System.Windows.Forms.Button()
        Me._pKey_61 = New System.Windows.Forms.Button()
        Me._pKey_63 = New System.Windows.Forms.Button()
        Me._pKey_49 = New System.Windows.Forms.Button()
        Me._pKey_51 = New System.Windows.Forms.Button()
        Me._pKey_54 = New System.Windows.Forms.Button()
        Me._pKey_56 = New System.Windows.Forms.Button()
        Me._pKey_58 = New System.Windows.Forms.Button()
        Me._pKey_46 = New System.Windows.Forms.Button()
        Me._pKey_44 = New System.Windows.Forms.Button()
        Me._pKey_42 = New System.Windows.Forms.Button()
        Me._pKey_39 = New System.Windows.Forms.Button()
        Me._pKey_37 = New System.Windows.Forms.Button()
        Me._pKey_34 = New System.Windows.Forms.Button()
        Me._pKey_32 = New System.Windows.Forms.Button()
        Me._pKey_30 = New System.Windows.Forms.Button()
        Me._pKey_27 = New System.Windows.Forms.Button()
        Me._pKey_25 = New System.Windows.Forms.Button()
        Me._pKey_22 = New System.Windows.Forms.Button()
        Me._pKey_20 = New System.Windows.Forms.Button()
        Me._pKey_18 = New System.Windows.Forms.Button()
        Me._pKey_15 = New System.Windows.Forms.Button()
        Me._pKey_13 = New System.Windows.Forms.Button()
        Me._pKey_10 = New System.Windows.Forms.Button()
        Me._pKey_8 = New System.Windows.Forms.Button()
        Me._pKey_6 = New System.Windows.Forms.Button()
        Me._pKey_3 = New System.Windows.Forms.Button()
        Me._pKey_1 = New System.Windows.Forms.Button()
        Me._pKey_64 = New System.Windows.Forms.Button()
        Me._pKey_62 = New System.Windows.Forms.Button()
        Me._pKey_60 = New System.Windows.Forms.Button()
        Me._pKey_59 = New System.Windows.Forms.Button()
        Me._pKey_57 = New System.Windows.Forms.Button()
        Me._pKey_55 = New System.Windows.Forms.Button()
        Me._pKey_53 = New System.Windows.Forms.Button()
        Me._pKey_52 = New System.Windows.Forms.Button()
        Me._pKey_50 = New System.Windows.Forms.Button()
        Me._pKey_48 = New System.Windows.Forms.Button()
        Me._pKey_47 = New System.Windows.Forms.Button()
        Me._pKey_45 = New System.Windows.Forms.Button()
        Me._pKey_43 = New System.Windows.Forms.Button()
        Me._pKey_41 = New System.Windows.Forms.Button()
        Me._pKey_40 = New System.Windows.Forms.Button()
        Me._pKey_38 = New System.Windows.Forms.Button()
        Me._pKey_36 = New System.Windows.Forms.Button()
        Me._pKey_35 = New System.Windows.Forms.Button()
        Me._pKey_33 = New System.Windows.Forms.Button()
        Me._pKey_31 = New System.Windows.Forms.Button()
        Me._pKey_29 = New System.Windows.Forms.Button()
        Me._pKey_28 = New System.Windows.Forms.Button()
        Me._pKey_26 = New System.Windows.Forms.Button()
        Me._pKey_24 = New System.Windows.Forms.Button()
        Me._pKey_23 = New System.Windows.Forms.Button()
        Me._pKey_21 = New System.Windows.Forms.Button()
        Me._pKey_19 = New System.Windows.Forms.Button()
        Me._pKey_17 = New System.Windows.Forms.Button()
        Me._pKey_16 = New System.Windows.Forms.Button()
        Me._pKey_14 = New System.Windows.Forms.Button()
        Me._pKey_12 = New System.Windows.Forms.Button()
        Me._pKey_11 = New System.Windows.Forms.Button()
        Me._pKey_9 = New System.Windows.Forms.Button()
        Me._pKey_7 = New System.Windows.Forms.Button()
        Me._pKey_5 = New System.Windows.Forms.Button()
        Me._pKey_4 = New System.Windows.Forms.Button()
        Me._pKey_2 = New System.Windows.Forms.Button()
        Me._pKey_0 = New System.Windows.Forms.Button()
        Me.pKey = New Microsoft.VisualBasic.Compatibility.VB6.ButtonArray(Me.components)
        Me.Label_midi = New System.Windows.Forms.Label()
        Me.Combo_output = New System.Windows.Forms.ComboBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.pKey, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '_pKey_70
        '
        Me._pKey_70.BackColor = System.Drawing.Color.Black
        Me._pKey_70.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_70.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_70, CType(70, Short))
        Me._pKey_70.Location = New System.Drawing.Point(654, 9)
        Me._pKey_70.Name = "_pKey_70"
        Me._pKey_70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_70.Size = New System.Drawing.Size(13, 57)
        Me._pKey_70.TabIndex = 71
        Me._pKey_70.TabStop = False
        Me._pKey_70.UseVisualStyleBackColor = False
        '
        '_pKey_68
        '
        Me._pKey_68.BackColor = System.Drawing.Color.Black
        Me._pKey_68.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_68.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_68, CType(68, Short))
        Me._pKey_68.Location = New System.Drawing.Point(638, 9)
        Me._pKey_68.Name = "_pKey_68"
        Me._pKey_68.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_68.Size = New System.Drawing.Size(13, 57)
        Me._pKey_68.TabIndex = 70
        Me._pKey_68.TabStop = False
        Me._pKey_68.UseVisualStyleBackColor = False
        '
        '_pKey_66
        '
        Me._pKey_66.BackColor = System.Drawing.Color.Black
        Me._pKey_66.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_66.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_66, CType(66, Short))
        Me._pKey_66.Location = New System.Drawing.Point(622, 9)
        Me._pKey_66.Name = "_pKey_66"
        Me._pKey_66.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_66.Size = New System.Drawing.Size(13, 57)
        Me._pKey_66.TabIndex = 69
        Me._pKey_66.TabStop = False
        Me._pKey_66.UseVisualStyleBackColor = False
        '
        '_pKey_71
        '
        Me._pKey_71.BackColor = System.Drawing.Color.White
        Me._pKey_71.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_71.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_71, CType(71, Short))
        Me._pKey_71.Location = New System.Drawing.Point(662, 9)
        Me._pKey_71.Name = "_pKey_71"
        Me._pKey_71.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_71.Size = New System.Drawing.Size(17, 97)
        Me._pKey_71.TabIndex = 68
        Me._pKey_71.TabStop = False
        Me._pKey_71.Tag = "1"
        Me._pKey_71.UseVisualStyleBackColor = False
        '
        '_pKey_69
        '
        Me._pKey_69.BackColor = System.Drawing.Color.White
        Me._pKey_69.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_69.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_69, CType(69, Short))
        Me._pKey_69.Location = New System.Drawing.Point(646, 9)
        Me._pKey_69.Name = "_pKey_69"
        Me._pKey_69.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_69.Size = New System.Drawing.Size(17, 97)
        Me._pKey_69.TabIndex = 67
        Me._pKey_69.TabStop = False
        Me._pKey_69.Tag = "1"
        Me._pKey_69.UseVisualStyleBackColor = False
        '
        '_pKey_67
        '
        Me._pKey_67.BackColor = System.Drawing.Color.White
        Me._pKey_67.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_67.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_67, CType(67, Short))
        Me._pKey_67.Location = New System.Drawing.Point(630, 9)
        Me._pKey_67.Name = "_pKey_67"
        Me._pKey_67.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_67.Size = New System.Drawing.Size(17, 97)
        Me._pKey_67.TabIndex = 66
        Me._pKey_67.TabStop = False
        Me._pKey_67.Tag = "1"
        Me._pKey_67.UseVisualStyleBackColor = False
        '
        '_pKey_65
        '
        Me._pKey_65.BackColor = System.Drawing.Color.White
        Me._pKey_65.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_65.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_65, CType(65, Short))
        Me._pKey_65.Location = New System.Drawing.Point(614, 9)
        Me._pKey_65.Name = "_pKey_65"
        Me._pKey_65.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_65.Size = New System.Drawing.Size(17, 97)
        Me._pKey_65.TabIndex = 65
        Me._pKey_65.TabStop = False
        Me._pKey_65.Tag = "1"
        Me._pKey_65.UseVisualStyleBackColor = False
        '
        '_pKey_61
        '
        Me._pKey_61.BackColor = System.Drawing.Color.Black
        Me._pKey_61.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_61.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_61, CType(61, Short))
        Me._pKey_61.Location = New System.Drawing.Point(575, 9)
        Me._pKey_61.Name = "_pKey_61"
        Me._pKey_61.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_61.Size = New System.Drawing.Size(13, 57)
        Me._pKey_61.TabIndex = 63
        Me._pKey_61.TabStop = False
        Me._pKey_61.UseVisualStyleBackColor = False
        '
        '_pKey_63
        '
        Me._pKey_63.BackColor = System.Drawing.Color.Black
        Me._pKey_63.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_63.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_63, CType(63, Short))
        Me._pKey_63.Location = New System.Drawing.Point(591, 9)
        Me._pKey_63.Name = "_pKey_63"
        Me._pKey_63.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_63.Size = New System.Drawing.Size(13, 57)
        Me._pKey_63.TabIndex = 64
        Me._pKey_63.TabStop = False
        Me._pKey_63.UseVisualStyleBackColor = False
        '
        '_pKey_49
        '
        Me._pKey_49.BackColor = System.Drawing.Color.Black
        Me._pKey_49.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_49.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_49, CType(49, Short))
        Me._pKey_49.Location = New System.Drawing.Point(463, 9)
        Me._pKey_49.Name = "_pKey_49"
        Me._pKey_49.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_49.Size = New System.Drawing.Size(13, 57)
        Me._pKey_49.TabIndex = 58
        Me._pKey_49.TabStop = False
        Me._pKey_49.UseVisualStyleBackColor = False
        '
        '_pKey_51
        '
        Me._pKey_51.BackColor = System.Drawing.Color.Black
        Me._pKey_51.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_51.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_51, CType(51, Short))
        Me._pKey_51.Location = New System.Drawing.Point(479, 9)
        Me._pKey_51.Name = "_pKey_51"
        Me._pKey_51.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_51.Size = New System.Drawing.Size(13, 57)
        Me._pKey_51.TabIndex = 59
        Me._pKey_51.TabStop = False
        Me._pKey_51.UseVisualStyleBackColor = False
        '
        '_pKey_54
        '
        Me._pKey_54.BackColor = System.Drawing.Color.Black
        Me._pKey_54.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_54.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_54, CType(54, Short))
        Me._pKey_54.Location = New System.Drawing.Point(511, 9)
        Me._pKey_54.Name = "_pKey_54"
        Me._pKey_54.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_54.Size = New System.Drawing.Size(13, 57)
        Me._pKey_54.TabIndex = 60
        Me._pKey_54.TabStop = False
        Me._pKey_54.UseVisualStyleBackColor = False
        '
        '_pKey_56
        '
        Me._pKey_56.BackColor = System.Drawing.Color.Black
        Me._pKey_56.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_56.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_56, CType(56, Short))
        Me._pKey_56.Location = New System.Drawing.Point(527, 9)
        Me._pKey_56.Name = "_pKey_56"
        Me._pKey_56.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_56.Size = New System.Drawing.Size(13, 57)
        Me._pKey_56.TabIndex = 61
        Me._pKey_56.TabStop = False
        Me._pKey_56.UseVisualStyleBackColor = False
        '
        '_pKey_58
        '
        Me._pKey_58.BackColor = System.Drawing.Color.Black
        Me._pKey_58.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_58.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_58, CType(58, Short))
        Me._pKey_58.Location = New System.Drawing.Point(543, 9)
        Me._pKey_58.Name = "_pKey_58"
        Me._pKey_58.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_58.Size = New System.Drawing.Size(13, 57)
        Me._pKey_58.TabIndex = 62
        Me._pKey_58.TabStop = False
        Me._pKey_58.UseVisualStyleBackColor = False
        '
        '_pKey_46
        '
        Me._pKey_46.BackColor = System.Drawing.Color.Black
        Me._pKey_46.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_46.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_46, CType(46, Short))
        Me._pKey_46.Location = New System.Drawing.Point(431, 9)
        Me._pKey_46.Name = "_pKey_46"
        Me._pKey_46.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_46.Size = New System.Drawing.Size(13, 57)
        Me._pKey_46.TabIndex = 57
        Me._pKey_46.TabStop = False
        Me._pKey_46.UseVisualStyleBackColor = False
        '
        '_pKey_44
        '
        Me._pKey_44.BackColor = System.Drawing.Color.Black
        Me._pKey_44.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_44.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_44, CType(44, Short))
        Me._pKey_44.Location = New System.Drawing.Point(415, 9)
        Me._pKey_44.Name = "_pKey_44"
        Me._pKey_44.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_44.Size = New System.Drawing.Size(13, 57)
        Me._pKey_44.TabIndex = 56
        Me._pKey_44.TabStop = False
        Me._pKey_44.UseVisualStyleBackColor = False
        '
        '_pKey_42
        '
        Me._pKey_42.BackColor = System.Drawing.Color.Black
        Me._pKey_42.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_42.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_42, CType(42, Short))
        Me._pKey_42.Location = New System.Drawing.Point(399, 9)
        Me._pKey_42.Name = "_pKey_42"
        Me._pKey_42.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_42.Size = New System.Drawing.Size(13, 57)
        Me._pKey_42.TabIndex = 55
        Me._pKey_42.TabStop = False
        Me._pKey_42.UseVisualStyleBackColor = False
        '
        '_pKey_39
        '
        Me._pKey_39.BackColor = System.Drawing.Color.Black
        Me._pKey_39.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_39.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_39, CType(39, Short))
        Me._pKey_39.Location = New System.Drawing.Point(367, 9)
        Me._pKey_39.Name = "_pKey_39"
        Me._pKey_39.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_39.Size = New System.Drawing.Size(13, 57)
        Me._pKey_39.TabIndex = 54
        Me._pKey_39.TabStop = False
        Me._pKey_39.UseVisualStyleBackColor = False
        '
        '_pKey_37
        '
        Me._pKey_37.BackColor = System.Drawing.Color.Black
        Me._pKey_37.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_37.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_37, CType(37, Short))
        Me._pKey_37.Location = New System.Drawing.Point(351, 9)
        Me._pKey_37.Name = "_pKey_37"
        Me._pKey_37.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_37.Size = New System.Drawing.Size(13, 57)
        Me._pKey_37.TabIndex = 53
        Me._pKey_37.TabStop = False
        Me._pKey_37.UseVisualStyleBackColor = False
        '
        '_pKey_34
        '
        Me._pKey_34.BackColor = System.Drawing.Color.Black
        Me._pKey_34.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_34.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_34, CType(34, Short))
        Me._pKey_34.Location = New System.Drawing.Point(319, 9)
        Me._pKey_34.Name = "_pKey_34"
        Me._pKey_34.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_34.Size = New System.Drawing.Size(13, 57)
        Me._pKey_34.TabIndex = 52
        Me._pKey_34.TabStop = False
        Me._pKey_34.UseVisualStyleBackColor = False
        '
        '_pKey_32
        '
        Me._pKey_32.BackColor = System.Drawing.Color.Black
        Me._pKey_32.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_32.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_32, CType(32, Short))
        Me._pKey_32.Location = New System.Drawing.Point(303, 9)
        Me._pKey_32.Name = "_pKey_32"
        Me._pKey_32.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_32.Size = New System.Drawing.Size(13, 57)
        Me._pKey_32.TabIndex = 51
        Me._pKey_32.TabStop = False
        Me._pKey_32.UseVisualStyleBackColor = False
        '
        '_pKey_30
        '
        Me._pKey_30.BackColor = System.Drawing.Color.Black
        Me._pKey_30.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_30.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_30, CType(30, Short))
        Me._pKey_30.Location = New System.Drawing.Point(287, 9)
        Me._pKey_30.Name = "_pKey_30"
        Me._pKey_30.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_30.Size = New System.Drawing.Size(13, 57)
        Me._pKey_30.TabIndex = 50
        Me._pKey_30.TabStop = False
        Me._pKey_30.UseVisualStyleBackColor = False
        '
        '_pKey_27
        '
        Me._pKey_27.BackColor = System.Drawing.Color.Black
        Me._pKey_27.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_27.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_27, CType(27, Short))
        Me._pKey_27.Location = New System.Drawing.Point(256, 9)
        Me._pKey_27.Name = "_pKey_27"
        Me._pKey_27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_27.Size = New System.Drawing.Size(13, 57)
        Me._pKey_27.TabIndex = 49
        Me._pKey_27.TabStop = False
        Me._pKey_27.UseVisualStyleBackColor = False
        '
        '_pKey_25
        '
        Me._pKey_25.BackColor = System.Drawing.Color.Black
        Me._pKey_25.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_25, CType(25, Short))
        Me._pKey_25.Location = New System.Drawing.Point(239, 9)
        Me._pKey_25.Name = "_pKey_25"
        Me._pKey_25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_25.Size = New System.Drawing.Size(13, 57)
        Me._pKey_25.TabIndex = 48
        Me._pKey_25.TabStop = False
        Me._pKey_25.UseVisualStyleBackColor = False
        '
        '_pKey_22
        '
        Me._pKey_22.BackColor = System.Drawing.Color.Black
        Me._pKey_22.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_22, CType(22, Short))
        Me._pKey_22.Location = New System.Drawing.Point(207, 9)
        Me._pKey_22.Name = "_pKey_22"
        Me._pKey_22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_22.Size = New System.Drawing.Size(13, 57)
        Me._pKey_22.TabIndex = 47
        Me._pKey_22.TabStop = False
        Me._pKey_22.UseVisualStyleBackColor = False
        '
        '_pKey_20
        '
        Me._pKey_20.BackColor = System.Drawing.Color.Black
        Me._pKey_20.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_20.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_20, CType(20, Short))
        Me._pKey_20.Location = New System.Drawing.Point(191, 9)
        Me._pKey_20.Name = "_pKey_20"
        Me._pKey_20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_20.Size = New System.Drawing.Size(13, 57)
        Me._pKey_20.TabIndex = 46
        Me._pKey_20.TabStop = False
        Me._pKey_20.UseVisualStyleBackColor = False
        '
        '_pKey_18
        '
        Me._pKey_18.BackColor = System.Drawing.Color.Black
        Me._pKey_18.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_18, CType(18, Short))
        Me._pKey_18.Location = New System.Drawing.Point(175, 9)
        Me._pKey_18.Name = "_pKey_18"
        Me._pKey_18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_18.Size = New System.Drawing.Size(13, 57)
        Me._pKey_18.TabIndex = 45
        Me._pKey_18.TabStop = False
        Me._pKey_18.UseVisualStyleBackColor = False
        '
        '_pKey_15
        '
        Me._pKey_15.BackColor = System.Drawing.Color.Black
        Me._pKey_15.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_15, CType(15, Short))
        Me._pKey_15.Location = New System.Drawing.Point(143, 9)
        Me._pKey_15.Name = "_pKey_15"
        Me._pKey_15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_15.Size = New System.Drawing.Size(13, 57)
        Me._pKey_15.TabIndex = 44
        Me._pKey_15.TabStop = False
        Me._pKey_15.UseVisualStyleBackColor = False
        '
        '_pKey_13
        '
        Me._pKey_13.BackColor = System.Drawing.Color.Black
        Me._pKey_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_13, CType(13, Short))
        Me._pKey_13.Location = New System.Drawing.Point(127, 9)
        Me._pKey_13.Name = "_pKey_13"
        Me._pKey_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_13.Size = New System.Drawing.Size(13, 57)
        Me._pKey_13.TabIndex = 43
        Me._pKey_13.TabStop = False
        Me._pKey_13.UseVisualStyleBackColor = False
        '
        '_pKey_10
        '
        Me._pKey_10.BackColor = System.Drawing.Color.Black
        Me._pKey_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_10, CType(10, Short))
        Me._pKey_10.Location = New System.Drawing.Point(96, 9)
        Me._pKey_10.Name = "_pKey_10"
        Me._pKey_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_10.Size = New System.Drawing.Size(13, 57)
        Me._pKey_10.TabIndex = 42
        Me._pKey_10.TabStop = False
        Me._pKey_10.UseVisualStyleBackColor = False
        '
        '_pKey_8
        '
        Me._pKey_8.BackColor = System.Drawing.Color.Black
        Me._pKey_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_8, CType(8, Short))
        Me._pKey_8.Location = New System.Drawing.Point(79, 9)
        Me._pKey_8.Name = "_pKey_8"
        Me._pKey_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_8.Size = New System.Drawing.Size(13, 57)
        Me._pKey_8.TabIndex = 41
        Me._pKey_8.TabStop = False
        Me._pKey_8.UseVisualStyleBackColor = False
        '
        '_pKey_6
        '
        Me._pKey_6.BackColor = System.Drawing.Color.Black
        Me._pKey_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_6, CType(6, Short))
        Me._pKey_6.Location = New System.Drawing.Point(63, 9)
        Me._pKey_6.Name = "_pKey_6"
        Me._pKey_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_6.Size = New System.Drawing.Size(13, 57)
        Me._pKey_6.TabIndex = 40
        Me._pKey_6.TabStop = False
        Me._pKey_6.UseVisualStyleBackColor = False
        '
        '_pKey_3
        '
        Me._pKey_3.BackColor = System.Drawing.Color.Black
        Me._pKey_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_3, CType(3, Short))
        Me._pKey_3.Location = New System.Drawing.Point(32, 9)
        Me._pKey_3.Name = "_pKey_3"
        Me._pKey_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_3.Size = New System.Drawing.Size(13, 57)
        Me._pKey_3.TabIndex = 39
        Me._pKey_3.TabStop = False
        Me._pKey_3.UseVisualStyleBackColor = False
        '
        '_pKey_1
        '
        Me._pKey_1.BackColor = System.Drawing.Color.Black
        Me._pKey_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_1, CType(1, Short))
        Me._pKey_1.Location = New System.Drawing.Point(15, 9)
        Me._pKey_1.Name = "_pKey_1"
        Me._pKey_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_1.Size = New System.Drawing.Size(13, 57)
        Me._pKey_1.TabIndex = 38
        Me._pKey_1.TabStop = False
        Me._pKey_1.UseVisualStyleBackColor = False
        '
        '_pKey_64
        '
        Me._pKey_64.BackColor = System.Drawing.Color.White
        Me._pKey_64.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_64.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_64, CType(64, Short))
        Me._pKey_64.Location = New System.Drawing.Point(598, 9)
        Me._pKey_64.Name = "_pKey_64"
        Me._pKey_64.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_64.Size = New System.Drawing.Size(17, 97)
        Me._pKey_64.TabIndex = 37
        Me._pKey_64.TabStop = False
        Me._pKey_64.Tag = "1"
        Me._pKey_64.UseVisualStyleBackColor = False
        '
        '_pKey_62
        '
        Me._pKey_62.BackColor = System.Drawing.Color.White
        Me._pKey_62.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_62.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_62, CType(62, Short))
        Me._pKey_62.Location = New System.Drawing.Point(582, 9)
        Me._pKey_62.Name = "_pKey_62"
        Me._pKey_62.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_62.Size = New System.Drawing.Size(17, 97)
        Me._pKey_62.TabIndex = 36
        Me._pKey_62.TabStop = False
        Me._pKey_62.Tag = "1"
        Me._pKey_62.UseVisualStyleBackColor = False
        '
        '_pKey_60
        '
        Me._pKey_60.BackColor = System.Drawing.Color.White
        Me._pKey_60.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_60.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_60, CType(60, Short))
        Me._pKey_60.Location = New System.Drawing.Point(566, 9)
        Me._pKey_60.Name = "_pKey_60"
        Me._pKey_60.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_60.Size = New System.Drawing.Size(17, 97)
        Me._pKey_60.TabIndex = 35
        Me._pKey_60.TabStop = False
        Me._pKey_60.Tag = "1"
        Me._pKey_60.UseVisualStyleBackColor = False
        '
        '_pKey_59
        '
        Me._pKey_59.BackColor = System.Drawing.Color.White
        Me._pKey_59.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_59.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_59, CType(59, Short))
        Me._pKey_59.Location = New System.Drawing.Point(550, 9)
        Me._pKey_59.Name = "_pKey_59"
        Me._pKey_59.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_59.Size = New System.Drawing.Size(17, 97)
        Me._pKey_59.TabIndex = 34
        Me._pKey_59.TabStop = False
        Me._pKey_59.Tag = "1"
        Me._pKey_59.UseVisualStyleBackColor = False
        '
        '_pKey_57
        '
        Me._pKey_57.BackColor = System.Drawing.Color.White
        Me._pKey_57.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_57.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_57, CType(57, Short))
        Me._pKey_57.Location = New System.Drawing.Point(534, 9)
        Me._pKey_57.Name = "_pKey_57"
        Me._pKey_57.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_57.Size = New System.Drawing.Size(17, 97)
        Me._pKey_57.TabIndex = 33
        Me._pKey_57.TabStop = False
        Me._pKey_57.Tag = "1"
        Me._pKey_57.UseVisualStyleBackColor = False
        '
        '_pKey_55
        '
        Me._pKey_55.BackColor = System.Drawing.Color.White
        Me._pKey_55.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_55.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_55, CType(55, Short))
        Me._pKey_55.Location = New System.Drawing.Point(518, 9)
        Me._pKey_55.Name = "_pKey_55"
        Me._pKey_55.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_55.Size = New System.Drawing.Size(17, 97)
        Me._pKey_55.TabIndex = 32
        Me._pKey_55.TabStop = False
        Me._pKey_55.Tag = "1"
        Me._pKey_55.UseVisualStyleBackColor = False
        '
        '_pKey_53
        '
        Me._pKey_53.BackColor = System.Drawing.Color.White
        Me._pKey_53.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_53.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_53, CType(53, Short))
        Me._pKey_53.Location = New System.Drawing.Point(502, 9)
        Me._pKey_53.Name = "_pKey_53"
        Me._pKey_53.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_53.Size = New System.Drawing.Size(17, 97)
        Me._pKey_53.TabIndex = 31
        Me._pKey_53.TabStop = False
        Me._pKey_53.Tag = "1"
        Me._pKey_53.UseVisualStyleBackColor = False
        '
        '_pKey_52
        '
        Me._pKey_52.BackColor = System.Drawing.Color.White
        Me._pKey_52.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_52.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_52, CType(52, Short))
        Me._pKey_52.Location = New System.Drawing.Point(486, 9)
        Me._pKey_52.Name = "_pKey_52"
        Me._pKey_52.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_52.Size = New System.Drawing.Size(17, 97)
        Me._pKey_52.TabIndex = 30
        Me._pKey_52.TabStop = False
        Me._pKey_52.Tag = "1"
        Me._pKey_52.UseVisualStyleBackColor = False
        '
        '_pKey_50
        '
        Me._pKey_50.BackColor = System.Drawing.Color.White
        Me._pKey_50.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_50.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_50, CType(50, Short))
        Me._pKey_50.Location = New System.Drawing.Point(470, 9)
        Me._pKey_50.Name = "_pKey_50"
        Me._pKey_50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_50.Size = New System.Drawing.Size(17, 97)
        Me._pKey_50.TabIndex = 29
        Me._pKey_50.TabStop = False
        Me._pKey_50.Tag = "1"
        Me._pKey_50.UseVisualStyleBackColor = False
        '
        '_pKey_48
        '
        Me._pKey_48.BackColor = System.Drawing.Color.White
        Me._pKey_48.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_48.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_48, CType(48, Short))
        Me._pKey_48.Location = New System.Drawing.Point(454, 9)
        Me._pKey_48.Name = "_pKey_48"
        Me._pKey_48.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_48.Size = New System.Drawing.Size(17, 97)
        Me._pKey_48.TabIndex = 28
        Me._pKey_48.TabStop = False
        Me._pKey_48.Tag = "1"
        Me._pKey_48.UseVisualStyleBackColor = False
        '
        '_pKey_47
        '
        Me._pKey_47.BackColor = System.Drawing.Color.White
        Me._pKey_47.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_47.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_47, CType(47, Short))
        Me._pKey_47.Location = New System.Drawing.Point(438, 9)
        Me._pKey_47.Name = "_pKey_47"
        Me._pKey_47.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_47.Size = New System.Drawing.Size(17, 97)
        Me._pKey_47.TabIndex = 27
        Me._pKey_47.TabStop = False
        Me._pKey_47.Tag = "1"
        Me._pKey_47.UseVisualStyleBackColor = False
        '
        '_pKey_45
        '
        Me._pKey_45.BackColor = System.Drawing.Color.White
        Me._pKey_45.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_45.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_45, CType(45, Short))
        Me._pKey_45.Location = New System.Drawing.Point(422, 9)
        Me._pKey_45.Name = "_pKey_45"
        Me._pKey_45.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_45.Size = New System.Drawing.Size(17, 97)
        Me._pKey_45.TabIndex = 26
        Me._pKey_45.TabStop = False
        Me._pKey_45.Tag = "1"
        Me._pKey_45.UseVisualStyleBackColor = False
        '
        '_pKey_43
        '
        Me._pKey_43.BackColor = System.Drawing.Color.White
        Me._pKey_43.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_43.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_43, CType(43, Short))
        Me._pKey_43.Location = New System.Drawing.Point(406, 9)
        Me._pKey_43.Name = "_pKey_43"
        Me._pKey_43.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_43.Size = New System.Drawing.Size(17, 97)
        Me._pKey_43.TabIndex = 25
        Me._pKey_43.TabStop = False
        Me._pKey_43.Tag = "1"
        Me._pKey_43.UseVisualStyleBackColor = False
        '
        '_pKey_41
        '
        Me._pKey_41.BackColor = System.Drawing.Color.White
        Me._pKey_41.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_41.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_41, CType(41, Short))
        Me._pKey_41.Location = New System.Drawing.Point(390, 9)
        Me._pKey_41.Name = "_pKey_41"
        Me._pKey_41.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_41.Size = New System.Drawing.Size(17, 97)
        Me._pKey_41.TabIndex = 24
        Me._pKey_41.TabStop = False
        Me._pKey_41.Tag = "1"
        Me._pKey_41.UseVisualStyleBackColor = False
        '
        '_pKey_40
        '
        Me._pKey_40.BackColor = System.Drawing.Color.White
        Me._pKey_40.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_40.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_40, CType(40, Short))
        Me._pKey_40.Location = New System.Drawing.Point(374, 9)
        Me._pKey_40.Name = "_pKey_40"
        Me._pKey_40.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_40.Size = New System.Drawing.Size(17, 97)
        Me._pKey_40.TabIndex = 23
        Me._pKey_40.TabStop = False
        Me._pKey_40.Tag = "1"
        Me._pKey_40.UseVisualStyleBackColor = False
        '
        '_pKey_38
        '
        Me._pKey_38.BackColor = System.Drawing.Color.White
        Me._pKey_38.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_38.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_38, CType(38, Short))
        Me._pKey_38.Location = New System.Drawing.Point(358, 9)
        Me._pKey_38.Name = "_pKey_38"
        Me._pKey_38.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_38.Size = New System.Drawing.Size(17, 97)
        Me._pKey_38.TabIndex = 22
        Me._pKey_38.TabStop = False
        Me._pKey_38.Tag = "1"
        Me._pKey_38.UseVisualStyleBackColor = False
        '
        '_pKey_36
        '
        Me._pKey_36.BackColor = System.Drawing.Color.White
        Me._pKey_36.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_36.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_36, CType(36, Short))
        Me._pKey_36.Location = New System.Drawing.Point(342, 9)
        Me._pKey_36.Name = "_pKey_36"
        Me._pKey_36.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_36.Size = New System.Drawing.Size(17, 97)
        Me._pKey_36.TabIndex = 21
        Me._pKey_36.TabStop = False
        Me._pKey_36.Tag = "1"
        Me._pKey_36.UseVisualStyleBackColor = False
        '
        '_pKey_35
        '
        Me._pKey_35.BackColor = System.Drawing.Color.White
        Me._pKey_35.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_35.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_35, CType(35, Short))
        Me._pKey_35.Location = New System.Drawing.Point(326, 9)
        Me._pKey_35.Name = "_pKey_35"
        Me._pKey_35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_35.Size = New System.Drawing.Size(17, 97)
        Me._pKey_35.TabIndex = 20
        Me._pKey_35.TabStop = False
        Me._pKey_35.Tag = "1"
        Me._pKey_35.UseVisualStyleBackColor = False
        '
        '_pKey_33
        '
        Me._pKey_33.BackColor = System.Drawing.Color.White
        Me._pKey_33.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_33.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_33, CType(33, Short))
        Me._pKey_33.Location = New System.Drawing.Point(310, 9)
        Me._pKey_33.Name = "_pKey_33"
        Me._pKey_33.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_33.Size = New System.Drawing.Size(17, 97)
        Me._pKey_33.TabIndex = 19
        Me._pKey_33.TabStop = False
        Me._pKey_33.Tag = "1"
        Me._pKey_33.UseVisualStyleBackColor = False
        '
        '_pKey_31
        '
        Me._pKey_31.BackColor = System.Drawing.Color.White
        Me._pKey_31.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_31.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_31, CType(31, Short))
        Me._pKey_31.Location = New System.Drawing.Point(294, 9)
        Me._pKey_31.Name = "_pKey_31"
        Me._pKey_31.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_31.Size = New System.Drawing.Size(17, 97)
        Me._pKey_31.TabIndex = 18
        Me._pKey_31.TabStop = False
        Me._pKey_31.Tag = "1"
        Me._pKey_31.UseVisualStyleBackColor = False
        '
        '_pKey_29
        '
        Me._pKey_29.BackColor = System.Drawing.Color.White
        Me._pKey_29.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_29.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_29, CType(29, Short))
        Me._pKey_29.Location = New System.Drawing.Point(278, 9)
        Me._pKey_29.Name = "_pKey_29"
        Me._pKey_29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_29.Size = New System.Drawing.Size(17, 97)
        Me._pKey_29.TabIndex = 17
        Me._pKey_29.TabStop = False
        Me._pKey_29.Tag = "1"
        Me._pKey_29.UseVisualStyleBackColor = False
        '
        '_pKey_28
        '
        Me._pKey_28.BackColor = System.Drawing.Color.White
        Me._pKey_28.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_28.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_28, CType(28, Short))
        Me._pKey_28.Location = New System.Drawing.Point(262, 9)
        Me._pKey_28.Name = "_pKey_28"
        Me._pKey_28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_28.Size = New System.Drawing.Size(17, 97)
        Me._pKey_28.TabIndex = 16
        Me._pKey_28.TabStop = False
        Me._pKey_28.Tag = "1"
        Me._pKey_28.UseVisualStyleBackColor = False
        '
        '_pKey_26
        '
        Me._pKey_26.BackColor = System.Drawing.Color.White
        Me._pKey_26.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_26.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_26, CType(26, Short))
        Me._pKey_26.Location = New System.Drawing.Point(246, 9)
        Me._pKey_26.Name = "_pKey_26"
        Me._pKey_26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_26.Size = New System.Drawing.Size(17, 97)
        Me._pKey_26.TabIndex = 15
        Me._pKey_26.TabStop = False
        Me._pKey_26.Tag = "1"
        Me._pKey_26.UseVisualStyleBackColor = False
        '
        '_pKey_24
        '
        Me._pKey_24.BackColor = System.Drawing.Color.White
        Me._pKey_24.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_24, CType(24, Short))
        Me._pKey_24.Location = New System.Drawing.Point(230, 9)
        Me._pKey_24.Name = "_pKey_24"
        Me._pKey_24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_24.Size = New System.Drawing.Size(17, 97)
        Me._pKey_24.TabIndex = 14
        Me._pKey_24.TabStop = False
        Me._pKey_24.Tag = "1"
        Me._pKey_24.UseVisualStyleBackColor = False
        '
        '_pKey_23
        '
        Me._pKey_23.BackColor = System.Drawing.Color.White
        Me._pKey_23.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_23, CType(23, Short))
        Me._pKey_23.Location = New System.Drawing.Point(214, 9)
        Me._pKey_23.Name = "_pKey_23"
        Me._pKey_23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_23.Size = New System.Drawing.Size(17, 97)
        Me._pKey_23.TabIndex = 13
        Me._pKey_23.TabStop = False
        Me._pKey_23.Tag = "1"
        Me._pKey_23.UseVisualStyleBackColor = False
        '
        '_pKey_21
        '
        Me._pKey_21.BackColor = System.Drawing.Color.White
        Me._pKey_21.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_21, CType(21, Short))
        Me._pKey_21.Location = New System.Drawing.Point(198, 9)
        Me._pKey_21.Name = "_pKey_21"
        Me._pKey_21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_21.Size = New System.Drawing.Size(17, 97)
        Me._pKey_21.TabIndex = 12
        Me._pKey_21.TabStop = False
        Me._pKey_21.Tag = "1"
        Me._pKey_21.UseVisualStyleBackColor = False
        '
        '_pKey_19
        '
        Me._pKey_19.BackColor = System.Drawing.Color.White
        Me._pKey_19.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_19, CType(19, Short))
        Me._pKey_19.Location = New System.Drawing.Point(182, 9)
        Me._pKey_19.Name = "_pKey_19"
        Me._pKey_19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_19.Size = New System.Drawing.Size(17, 97)
        Me._pKey_19.TabIndex = 11
        Me._pKey_19.TabStop = False
        Me._pKey_19.Tag = "1"
        Me._pKey_19.UseVisualStyleBackColor = False
        '
        '_pKey_17
        '
        Me._pKey_17.BackColor = System.Drawing.Color.White
        Me._pKey_17.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_17, CType(17, Short))
        Me._pKey_17.Location = New System.Drawing.Point(166, 9)
        Me._pKey_17.Name = "_pKey_17"
        Me._pKey_17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_17.Size = New System.Drawing.Size(17, 97)
        Me._pKey_17.TabIndex = 10
        Me._pKey_17.TabStop = False
        Me._pKey_17.Tag = "1"
        Me._pKey_17.UseVisualStyleBackColor = False
        '
        '_pKey_16
        '
        Me._pKey_16.BackColor = System.Drawing.Color.White
        Me._pKey_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_16, CType(16, Short))
        Me._pKey_16.Location = New System.Drawing.Point(150, 9)
        Me._pKey_16.Name = "_pKey_16"
        Me._pKey_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_16.Size = New System.Drawing.Size(17, 97)
        Me._pKey_16.TabIndex = 9
        Me._pKey_16.TabStop = False
        Me._pKey_16.Tag = "1"
        Me._pKey_16.UseVisualStyleBackColor = False
        '
        '_pKey_14
        '
        Me._pKey_14.BackColor = System.Drawing.Color.White
        Me._pKey_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_14, CType(14, Short))
        Me._pKey_14.Location = New System.Drawing.Point(134, 9)
        Me._pKey_14.Name = "_pKey_14"
        Me._pKey_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_14.Size = New System.Drawing.Size(17, 97)
        Me._pKey_14.TabIndex = 8
        Me._pKey_14.TabStop = False
        Me._pKey_14.Tag = "1"
        Me._pKey_14.UseVisualStyleBackColor = False
        '
        '_pKey_12
        '
        Me._pKey_12.BackColor = System.Drawing.Color.White
        Me._pKey_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_12, CType(12, Short))
        Me._pKey_12.Location = New System.Drawing.Point(118, 9)
        Me._pKey_12.Name = "_pKey_12"
        Me._pKey_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_12.Size = New System.Drawing.Size(17, 97)
        Me._pKey_12.TabIndex = 7
        Me._pKey_12.TabStop = False
        Me._pKey_12.Tag = "1"
        Me._pKey_12.UseVisualStyleBackColor = False
        '
        '_pKey_11
        '
        Me._pKey_11.BackColor = System.Drawing.Color.White
        Me._pKey_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_11, CType(11, Short))
        Me._pKey_11.Location = New System.Drawing.Point(102, 9)
        Me._pKey_11.Name = "_pKey_11"
        Me._pKey_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_11.Size = New System.Drawing.Size(17, 97)
        Me._pKey_11.TabIndex = 6
        Me._pKey_11.TabStop = False
        Me._pKey_11.Tag = "1"
        Me._pKey_11.UseVisualStyleBackColor = False
        '
        '_pKey_9
        '
        Me._pKey_9.BackColor = System.Drawing.Color.White
        Me._pKey_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_9, CType(9, Short))
        Me._pKey_9.Location = New System.Drawing.Point(86, 9)
        Me._pKey_9.Name = "_pKey_9"
        Me._pKey_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_9.Size = New System.Drawing.Size(17, 97)
        Me._pKey_9.TabIndex = 5
        Me._pKey_9.TabStop = False
        Me._pKey_9.Tag = "1"
        Me._pKey_9.UseVisualStyleBackColor = False
        '
        '_pKey_7
        '
        Me._pKey_7.BackColor = System.Drawing.Color.White
        Me._pKey_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_7, CType(7, Short))
        Me._pKey_7.Location = New System.Drawing.Point(70, 9)
        Me._pKey_7.Name = "_pKey_7"
        Me._pKey_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_7.Size = New System.Drawing.Size(17, 97)
        Me._pKey_7.TabIndex = 4
        Me._pKey_7.TabStop = False
        Me._pKey_7.Tag = "1"
        Me._pKey_7.UseVisualStyleBackColor = False
        '
        '_pKey_5
        '
        Me._pKey_5.BackColor = System.Drawing.Color.White
        Me._pKey_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_5, CType(5, Short))
        Me._pKey_5.Location = New System.Drawing.Point(54, 9)
        Me._pKey_5.Name = "_pKey_5"
        Me._pKey_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_5.Size = New System.Drawing.Size(17, 97)
        Me._pKey_5.TabIndex = 3
        Me._pKey_5.TabStop = False
        Me._pKey_5.Tag = "1"
        Me._pKey_5.UseVisualStyleBackColor = False
        '
        '_pKey_4
        '
        Me._pKey_4.BackColor = System.Drawing.Color.White
        Me._pKey_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_4, CType(4, Short))
        Me._pKey_4.Location = New System.Drawing.Point(38, 9)
        Me._pKey_4.Name = "_pKey_4"
        Me._pKey_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_4.Size = New System.Drawing.Size(17, 97)
        Me._pKey_4.TabIndex = 2
        Me._pKey_4.TabStop = False
        Me._pKey_4.Tag = "1"
        Me._pKey_4.UseVisualStyleBackColor = False
        '
        '_pKey_2
        '
        Me._pKey_2.BackColor = System.Drawing.Color.White
        Me._pKey_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_2, CType(2, Short))
        Me._pKey_2.Location = New System.Drawing.Point(22, 9)
        Me._pKey_2.Name = "_pKey_2"
        Me._pKey_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_2.Size = New System.Drawing.Size(17, 97)
        Me._pKey_2.TabIndex = 1
        Me._pKey_2.TabStop = False
        Me._pKey_2.Tag = "1"
        Me._pKey_2.UseVisualStyleBackColor = False
        '
        '_pKey_0
        '
        Me._pKey_0.BackColor = System.Drawing.Color.White
        Me._pKey_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._pKey_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pKey.SetIndex(Me._pKey_0, CType(0, Short))
        Me._pKey_0.Location = New System.Drawing.Point(6, 9)
        Me._pKey_0.Name = "_pKey_0"
        Me._pKey_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._pKey_0.Size = New System.Drawing.Size(17, 97)
        Me._pKey_0.TabIndex = 0
        Me._pKey_0.TabStop = False
        Me._pKey_0.Tag = "1"
        Me._pKey_0.UseVisualStyleBackColor = False
        '
        'pKey
        '
        '
        'Label_midi
        '
        Me.Label_midi.AutoSize = True
        Me.Label_midi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_midi.Location = New System.Drawing.Point(686, 14)
        Me.Label_midi.Name = "Label_midi"
        Me.Label_midi.Size = New System.Drawing.Size(79, 16)
        Me.Label_midi.TabIndex = 88
        Me.Label_midi.Text = "MIDI  OUT"
        '
        'Combo_output
        '
        Me.Combo_output.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Combo_output.FormattingEnabled = True
        Me.Combo_output.Location = New System.Drawing.Point(767, 9)
        Me.Combo_output.Name = "Combo_output"
        Me.Combo_output.Size = New System.Drawing.Size(143, 23)
        Me.Combo_output.TabIndex = 86
        '
        'CheckBox6
        '
        Me.CheckBox6.Appearance = System.Windows.Forms.Appearance.Button
        Me.CheckBox6.BackColor = System.Drawing.Color.YellowGreen
        Me.CheckBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CheckBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckBox6.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox6.ForeColor = System.Drawing.Color.Black
        Me.CheckBox6.Location = New System.Drawing.Point(6, 126)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(216, 67)
        Me.CheckBox6.TabIndex = 2056
        Me.CheckBox6.Text = "G R I D    N O T E S"
        Me.CheckBox6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CheckBox6.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(234, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(602, 25)
        Me.Label1.TabIndex = 2057
        Me.Label1.Text = "Piano Roll  /  Beat Box  using  DRYWETMIDI.DLL library"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(236, 126)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(342, 25)
        Me.LinkLabel1.TabIndex = 2058
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "melanchall.github.io/drywetmidi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(686, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(182, 80)
        Me.Label2.TabIndex = 2059
        Me.Label2.Text = "Simply roll notes using" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " a datagridview object" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "I need help to manipulate" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "not" &
    "es duration !!!!"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(585, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 16)
        Me.Label3.TabIndex = 2060
        Me.Label3.Text = "<--Support !"
        '
        'frmPiano
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(954, 205)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CheckBox6)
        Me.Controls.Add(Me.Label_midi)
        Me.Controls.Add(Me.Combo_output)
        Me.Controls.Add(Me._pKey_70)
        Me.Controls.Add(Me._pKey_68)
        Me.Controls.Add(Me._pKey_66)
        Me.Controls.Add(Me._pKey_71)
        Me.Controls.Add(Me._pKey_69)
        Me.Controls.Add(Me._pKey_67)
        Me.Controls.Add(Me._pKey_65)
        Me.Controls.Add(Me._pKey_61)
        Me.Controls.Add(Me._pKey_63)
        Me.Controls.Add(Me._pKey_49)
        Me.Controls.Add(Me._pKey_51)
        Me.Controls.Add(Me._pKey_54)
        Me.Controls.Add(Me._pKey_56)
        Me.Controls.Add(Me._pKey_58)
        Me.Controls.Add(Me._pKey_46)
        Me.Controls.Add(Me._pKey_44)
        Me.Controls.Add(Me._pKey_42)
        Me.Controls.Add(Me._pKey_39)
        Me.Controls.Add(Me._pKey_37)
        Me.Controls.Add(Me._pKey_34)
        Me.Controls.Add(Me._pKey_32)
        Me.Controls.Add(Me._pKey_30)
        Me.Controls.Add(Me._pKey_27)
        Me.Controls.Add(Me._pKey_25)
        Me.Controls.Add(Me._pKey_22)
        Me.Controls.Add(Me._pKey_20)
        Me.Controls.Add(Me._pKey_18)
        Me.Controls.Add(Me._pKey_15)
        Me.Controls.Add(Me._pKey_13)
        Me.Controls.Add(Me._pKey_10)
        Me.Controls.Add(Me._pKey_8)
        Me.Controls.Add(Me._pKey_6)
        Me.Controls.Add(Me._pKey_3)
        Me.Controls.Add(Me._pKey_1)
        Me.Controls.Add(Me._pKey_64)
        Me.Controls.Add(Me._pKey_62)
        Me.Controls.Add(Me._pKey_60)
        Me.Controls.Add(Me._pKey_59)
        Me.Controls.Add(Me._pKey_57)
        Me.Controls.Add(Me._pKey_55)
        Me.Controls.Add(Me._pKey_53)
        Me.Controls.Add(Me._pKey_52)
        Me.Controls.Add(Me._pKey_50)
        Me.Controls.Add(Me._pKey_48)
        Me.Controls.Add(Me._pKey_47)
        Me.Controls.Add(Me._pKey_45)
        Me.Controls.Add(Me._pKey_43)
        Me.Controls.Add(Me._pKey_41)
        Me.Controls.Add(Me._pKey_40)
        Me.Controls.Add(Me._pKey_38)
        Me.Controls.Add(Me._pKey_36)
        Me.Controls.Add(Me._pKey_35)
        Me.Controls.Add(Me._pKey_33)
        Me.Controls.Add(Me._pKey_31)
        Me.Controls.Add(Me._pKey_29)
        Me.Controls.Add(Me._pKey_28)
        Me.Controls.Add(Me._pKey_26)
        Me.Controls.Add(Me._pKey_24)
        Me.Controls.Add(Me._pKey_23)
        Me.Controls.Add(Me._pKey_21)
        Me.Controls.Add(Me._pKey_19)
        Me.Controls.Add(Me._pKey_17)
        Me.Controls.Add(Me._pKey_16)
        Me.Controls.Add(Me._pKey_14)
        Me.Controls.Add(Me._pKey_12)
        Me.Controls.Add(Me._pKey_11)
        Me.Controls.Add(Me._pKey_9)
        Me.Controls.Add(Me._pKey_7)
        Me.Controls.Add(Me._pKey_5)
        Me.Controls.Add(Me._pKey_4)
        Me.Controls.Add(Me._pKey_2)
        Me.Controls.Add(Me._pKey_0)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(213, 289)
        Me.MaximizeBox = False
        Me.Name = "frmPiano"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Simple DATAGRID ROLL NOTES"
        Me.TopMost = True
        CType(Me.pKey, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label_midi As Label
    Friend WithEvents Combo_output As ComboBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label


#End Region
End Class