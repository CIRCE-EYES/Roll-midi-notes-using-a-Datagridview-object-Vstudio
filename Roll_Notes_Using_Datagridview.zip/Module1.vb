Option Strict Off
Option Explicit On
Module Module1
	Public Function playChordS(ByRef ChordName As String) As String

        Select Case ChordName

            Case "0"
                frmPiano.domusic(0) : Case "1" : frmPiano.domusic(1) : Case "2" : frmPiano.domusic(2) : Case "3" : frmPiano.domusic(3) : Case "4" : frmPiano.domusic(4) : Case "5" : frmPiano.domusic(5) : Case "6" : frmPiano.domusic(6) : Case "7" : frmPiano.domusic(7) : Case "8" : frmPiano.domusic(8) : Case "9" : frmPiano.domusic(9) : Case "10" : frmPiano.domusic(10) : Case "11" : frmPiano.domusic(11)
            Case "12"
                frmPiano.domusic(12) : Case "13" : frmPiano.domusic(13) : Case "14" : frmPiano.domusic(14) : Case "15" : frmPiano.domusic(15) : Case "16" : frmPiano.domusic(16) : Case "17" : frmPiano.domusic(17) : Case "18" : frmPiano.domusic(18) : Case "19" : frmPiano.domusic(19) : Case "20" : frmPiano.domusic(20) : Case "21" : frmPiano.domusic(21) : Case "22" : frmPiano.domusic(22) : Case "23" : frmPiano.domusic(23)
            Case "24"
                frmPiano.domusic(24) : Case "25" : frmPiano.domusic(25) : Case "26" : frmPiano.domusic(26) : Case "27" : frmPiano.domusic(27) : Case "28" : frmPiano.domusic(28) : Case "29" : frmPiano.domusic(29) : Case "30" : frmPiano.domusic(30) : Case "31" : frmPiano.domusic(31) : Case "32" : frmPiano.domusic(32) : Case "33" : frmPiano.domusic(33) : Case "34" : frmPiano.domusic(34) : Case "35" : frmPiano.domusic(35)
            Case "36"
                frmPiano.domusic(36) : Case "37" : frmPiano.domusic(37) : Case "38" : frmPiano.domusic(38) : Case "39" : frmPiano.domusic(39) : Case "40" : frmPiano.domusic(40) : Case "41" : frmPiano.domusic(41) : Case "42" : frmPiano.domusic(42) : Case "43" : frmPiano.domusic(43) : Case "44" : frmPiano.domusic(44) : Case "45" : frmPiano.domusic(45) : Case "46" : frmPiano.domusic(46)
            Case "47"
                frmPiano.domusic(47) : Case "48" : frmPiano.domusic(48) : Case "49" : frmPiano.domusic(49) : Case "50" : frmPiano.domusic(50) : Case "51" : frmPiano.domusic(51) : Case "52" : frmPiano.domusic(52) : Case "53" : frmPiano.domusic(53) : Case "54" : frmPiano.domusic(54) : Case "55" : frmPiano.domusic(55) : Case "56" : frmPiano.domusic(56) : Case "57" : frmPiano.domusic(57)
            Case "58"
                frmPiano.domusic(58) : Case "59" : frmPiano.domusic(59) : Case "60" : frmPiano.domusic(60) : Case "61" : frmPiano.domusic(61) : Case "62" : frmPiano.domusic(62) : Case "63" : frmPiano.domusic(63) : Case "64" : frmPiano.domusic(64) : Case "65" : frmPiano.domusic(65) : Case "66" : frmPiano.domusic(66) : Case "67" : frmPiano.domusic(67) : Case "68" : frmPiano.domusic(68)
            Case "69" : frmPiano.domusic(69) : Case "70" : frmPiano.domusic(70) : Case "71" : frmPiano.domusic(71)

        End Select
    End Function

    Public Function playChordE(ChordName As String) As String

        Select Case ChordName

            Case "0"
                frmPiano.domusicstop(0) : Case "1" : frmPiano.domusicstop(1) : Case "2" : frmPiano.domusicstop(2) : Case "3" : frmPiano.domusicstop(3) : Case "4" : frmPiano.domusicstop(4) : Case "5" : frmPiano.domusicstop(5) : Case "6" : frmPiano.domusicstop(6) : Case "7" : frmPiano.domusicstop(7) : Case "8" : frmPiano.domusicstop(8) : Case "9" : frmPiano.domusicstop(9) : Case "10" : frmPiano.domusicstop(10) : Case "11" : frmPiano.domusicstop(11)
            Case "12"
                frmPiano.domusicstop(12) : Case "13" : frmPiano.domusicstop(13) : Case "14" : frmPiano.domusicstop(14) : Case "15" : frmPiano.domusicstop(15) : Case "16" : frmPiano.domusicstop(16) : Case "17" : frmPiano.domusicstop(17) : Case "18" : frmPiano.domusicstop(18) : Case "19" : frmPiano.domusicstop(19) : Case "20" : frmPiano.domusicstop(20) : Case "21" : frmPiano.domusicstop(21) : Case "22" : frmPiano.domusicstop(22) : Case "23" : frmPiano.domusicstop(23)
            Case "24"
                frmPiano.domusicstop(24) : Case "25" : frmPiano.domusicstop(25) : Case "26" : frmPiano.domusicstop(26) : Case "27" : frmPiano.domusicstop(27) : Case "28" : frmPiano.domusicstop(28) : Case "29" : frmPiano.domusicstop(29) : Case "30" : frmPiano.domusicstop(30) : Case "31" : frmPiano.domusicstop(31) : Case "32" : frmPiano.domusicstop(32) : Case "33" : frmPiano.domusicstop(33) : Case "34" : frmPiano.domusicstop(34) : Case "35" : frmPiano.domusicstop(35)
            Case "36"
                frmPiano.domusicstop(36) : Case "37" : frmPiano.domusicstop(37) : Case "38" : frmPiano.domusicstop(38) : Case "39" : frmPiano.domusicstop(39) : Case "40" : frmPiano.domusicstop(40) : Case "41" : frmPiano.domusicstop(41) : Case "42" : frmPiano.domusicstop(42) : Case "43" : frmPiano.domusicstop(43) : Case "44" : frmPiano.domusicstop(44) : Case "45" : frmPiano.domusicstop(45) : Case "46" : frmPiano.domusicstop(46)
            Case "47"
                frmPiano.domusicstop(47) : Case "48" : frmPiano.domusicstop(48) : Case "49" : frmPiano.domusicstop(49) : Case "50" : frmPiano.domusicstop(50) : Case "51" : frmPiano.domusicstop(51) : Case "52" : frmPiano.domusicstop(52) : Case "53" : frmPiano.domusicstop(53) : Case "54" : frmPiano.domusicstop(54) : Case "55" : frmPiano.domusicstop(55) : Case "56" : frmPiano.domusicstop(56) : Case "57" : frmPiano.domusicstop(57)
            Case "58"
                frmPiano.domusicstop(58) : Case "59" : frmPiano.domusicstop(59) : Case "60" : frmPiano.domusicstop(60) : Case "61" : frmPiano.domusicstop(61) : Case "62" : frmPiano.domusicstop(62) : Case "63" : frmPiano.domusicstop(63) : Case "64" : frmPiano.domusicstop(64) : Case "65" : frmPiano.domusicstop(65) : Case "66" : frmPiano.domusicstop(66) : Case "67" : frmPiano.domusicstop(67) : Case "68" : frmPiano.domusicstop(68)
            Case "69" : frmPiano.domusicstop(69) : Case "70" : frmPiano.domusicstop(70) : Case "71" : frmPiano.domusicstop(71)

        End Select
    End Function
End Module